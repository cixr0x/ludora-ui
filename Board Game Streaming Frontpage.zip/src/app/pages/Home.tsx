import { useState, useRef, useEffect, useCallback } from "react";
import { Search, Dices, Bell, User, X, ChevronLeft, ChevronRight } from "lucide-react";
import { useNavigate, Link } from "react-router";
import { GameRow } from "../components/GameRow";
import { getAllGames, strategyGames, partyGames, classicGames, rpgGames, quickGames } from "../data/games";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { t } from "../data/translations";

const GENRES = [
  "Strategy", "Party", "Classic", "RPG", "Cooperative", "Deck Building",
  "Worker Placement", "Abstract", "Family", "Social Deduction", "Bluffing",
  "Tile Placement", "Hand Management", "Set Collection", "Drafting", "Engine Building",
  "Area Control", "Push Your Luck", "Legacy", "Roll & Write", "Negotiation",
  "Fantasy", "Horror", "Economic", "Card Game", "Dice Rolling", "Adventure",
  "Auction", "Trading", "Pattern Building",
];

const ALL_ROWS = [
  { title: "Juegos de Estrategia",  games: strategyGames },
  { title: "Noche de Juegos",        games: partyGames },
  { title: "Favoritos Clásicos",     games: classicGames },
  { title: "RPG y Aventura",         games: rpgGames },
  { title: "Rápido y Fácil",         games: quickGames },
];

export function Home() {
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchValue, setSearchValue] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const genreScrollRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  const allGames = getAllGames();

  const searchResults = searchValue.trim().length >= 2
    ? allGames.filter((g) =>
        g.name.toLowerCase().includes(searchValue.toLowerCase()) ||
        (g.altTitle?.toLowerCase().includes(searchValue.toLowerCase()))
      ).slice(0, 8)
    : [];

  const openSearch = () => {
    setSearchOpen(true);
    setTimeout(() => inputRef.current?.focus(), 50);
  };

  const closeSearch = () => {
    setSearchOpen(false);
    setSearchValue("");
  };

  const handleSearchBlur = useCallback(() => {
    setTimeout(() => setSearchOpen(false), 150);
  }, []);

  const handleResultClick = (id: number) => {
    closeSearch();
    navigate(`/game/${id}`);
  };

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeSearch();
    };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, []);

  const scrollGenre = (dir: "left" | "right") => {
    const el = genreScrollRef.current;
    if (!el) return;
    const atStart = el.scrollLeft <= 4;
    const atEnd = el.scrollLeft >= el.scrollWidth - el.clientWidth - 4;
    if (dir === "left" && atStart) {
      el.scrollTo({ left: el.scrollWidth, behavior: "smooth" });
    } else if (dir === "right" && atEnd) {
      el.scrollTo({ left: 0, behavior: "smooth" });
    } else {
      el.scrollBy({ left: dir === "left" ? -240 : 240, behavior: "smooth" });
    }
  };

  return (
    <div
      className="min-h-screen text-white"
      style={{
        background: "radial-gradient(ellipse 130% 38% at 50% -5%, rgba(217, 70, 239, 0.08) 0%, transparent 58%), rgb(10, 10, 10)",
      }}
    >
      {/* Navbar */}
      <header className="sticky top-0 z-50 bg-neutral-950/85 backdrop-blur-md border-b border-white/5">
        <div className="flex items-center justify-between px-8 h-16">
          {/* Brand */}
          <div className="flex items-center gap-2.5">
            <div className="bg-fuchsia-500 rounded-lg p-1.5">
              <Dices className="w-5 h-5 text-white" />
            </div>
            <span className="text-lg tracking-tight text-white">
              Board<span className="text-fuchsia-400">Vault</span>
            </span>
          </div>

          {/* Nav links */}
          <nav className="hidden md:flex items-center gap-7">
            <Link to="/search" className="text-sm text-neutral-400 hover:text-white transition-colors">Explorar</Link>
            {["Novedades", "Mejor Valorados", "Colecciones"].map((link) => (
              <button key={link} className="text-sm text-neutral-400 hover:text-white transition-colors">
                {link}
              </button>
            ))}
          </nav>

          {/* Right actions */}
          <div className="flex items-center gap-3">
            <div className="relative">
              <div
                className={`flex items-center gap-2 rounded-full border transition-all duration-200 ${
                  searchOpen
                    ? "bg-neutral-800 border-neutral-600 px-3 py-1.5"
                    : "border-transparent px-2 py-1.5"
                }`}
              >
                <button onClick={searchOpen ? undefined : openSearch} className="flex-none">
                  <Search className="w-4 h-4 text-neutral-400" />
                </button>
                <input
                  ref={inputRef}
                  type="text"
                  placeholder="Buscar juegos…"
                  value={searchValue}
                  onChange={(e) => setSearchValue(e.target.value)}
                  onBlur={handleSearchBlur}
                  className={`bg-transparent text-sm text-white placeholder:text-neutral-500 outline-none transition-all duration-200 ${
                    searchOpen ? "w-44" : "w-0 opacity-0 pointer-events-none"
                  }`}
                />
                {searchOpen && (
                  <button
                    onMouseDown={(e) => { e.preventDefault(); closeSearch(); }}
                    className="flex-none text-neutral-500 hover:text-neutral-300 transition-colors"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {searchOpen && searchValue.trim().length >= 2 && (
                <div className="absolute right-0 top-full mt-2 w-80 bg-neutral-900 border border-neutral-700 rounded-xl shadow-2xl overflow-hidden z-50">
                  {searchResults.length === 0 ? (
                    <div className="px-4 py-6 text-center text-neutral-500 text-sm">
                      No se encontraron juegos para "{searchValue}"
                    </div>
                  ) : (
                    <>
                      <div className="px-3 py-2 border-b border-neutral-800">
                        <p className="text-neutral-500 text-xs uppercase tracking-wider">
                          {searchResults.length} resultado{searchResults.length !== 1 ? "s" : ""}
                        </p>
                      </div>
                      {searchResults.map((game) => (
                        <button
                          key={game.id}
                          onMouseDown={() => handleResultClick(game.id)}
                          className="w-full flex items-center gap-3 px-3 py-2.5 hover:bg-neutral-800 transition-colors text-left"
                        >
                          <div className="flex-none w-9 h-9 rounded-md overflow-hidden bg-neutral-800">
                            <ImageWithFallback
                              src={game.image}
                              alt={game.name}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-white text-sm truncate">{game.name}</p>
                            {game.altTitle && (
                              <p className="text-neutral-500 text-xs truncate">{game.altTitle}</p>
                            )}
                          </div>
                        </button>
                      ))}
                    </>
                  )}
                </div>
              )}
            </div>

            <button className="relative p-2 rounded-full hover:bg-white/10 transition-colors">
              <Bell className="w-4 h-4 text-neutral-400" />
              <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-fuchsia-400 rounded-full" />
            </button>
            <button className="flex items-center justify-center w-8 h-8 rounded-full bg-fuchsia-500/20 text-fuchsia-400 hover:bg-fuchsia-500/30 transition-colors">
              <User className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Genre stripe */}
        <div className="flex items-center px-6 pb-3 gap-1 border-b border-white/5">
          <button
            onClick={() => scrollGenre("left")}
            aria-label="Scroll left"
            className="flex-none p-1 text-neutral-500 hover:text-white transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <div
            ref={genreScrollRef}
            className="flex items-center gap-7 overflow-x-auto min-w-0 flex-1"
            style={{ scrollbarWidth: "none" }}
          >
            {GENRES.map((genre) => (
              <Link
                key={genre}
                to={`/browse/${encodeURIComponent(genre)}`}
                className="flex-none text-sm whitespace-nowrap text-neutral-400 hover:text-white transition-colors"
              >
                {t(genre)}
              </Link>
            ))}
          </div>
          <button
            onClick={() => scrollGenre("right")}
            aria-label="Scroll right"
            className="flex-none p-1 text-neutral-500 hover:text-white transition-colors"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main content */}
      <main className="pt-8 pb-16">
        {ALL_ROWS.map((row) => (
          <GameRow key={row.title} title={row.title} games={row.games} />
        ))}
      </main>
    </div>
  );
}
