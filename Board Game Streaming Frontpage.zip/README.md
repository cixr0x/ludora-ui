
  # Board Game Streaming Frontpage

  This is a code bundle for Board Game Streaming Frontpage. The original project is available at https://www.figma.com/design/pUWKClPIMus1NXiOUdkc6L/Board-Game-Streaming-Frontpage.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  